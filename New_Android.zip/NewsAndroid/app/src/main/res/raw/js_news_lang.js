var lang={
     "ja":{
        "Common_ReadThisOnTheWeb": "オリジナルサイトで読む"
     },
     "en":{
        "Common_ReadThisOnTheWeb": "Read this on the web"
     },
     "zh-hans":{
        "Common_ReadThisOnTheWeb": "跳转至原网页"
     },
     "zh-hant":{
        "Common_ReadThisOnTheWeb": "オリジナルサイトで読む"
     },
     "ko":{
        "Common_ReadThisOnTheWeb": "オリジナルサイトで読む"
     }
}