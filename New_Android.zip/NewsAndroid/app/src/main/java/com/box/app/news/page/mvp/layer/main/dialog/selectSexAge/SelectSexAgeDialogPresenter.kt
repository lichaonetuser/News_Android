package com.box.app.news.page.mvp.layer.main.dialog.selectSexAge

import com.box.common.extension.app.mvp.dialog.MVPDialogPresenter

/**
 *
 */
class SelectSexAgeDialogPresenter : MVPDialogPresenter<SelectSexAgeDialogContract.View>(),
        SelectSexAgeDialogContract.Presenter<SelectSexAgeDialogContract.View> {

    override fun onClickSkip() {

    }

    override fun onClickConfirm() {

    }

}